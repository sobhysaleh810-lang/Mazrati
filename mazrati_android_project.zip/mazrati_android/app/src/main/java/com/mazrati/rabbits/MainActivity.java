package com.mazrati.rabbits;
import android.app.Activity;
import android.content.ContentValues;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.webkit.*;
import android.widget.Toast;
import android.util.Base64;
import java.io.OutputStream;

public class MainActivity extends Activity {
 private WebView webView; private ValueCallback<Uri[]> fileCallback; private static final int FILE_CHOOSER=701;
 @Override public void onCreate(Bundle state) {
  super.onCreate(state); getWindow().setStatusBarColor(0xFF173F35); getWindow().setNavigationBarColor(0xFF173F35);
  webView=new WebView(this); setContentView(webView);
  WebSettings settings=webView.getSettings(); settings.setJavaScriptEnabled(true); settings.setDomStorageEnabled(true);
  settings.setAllowFileAccess(true); settings.setAllowContentAccess(true); settings.setDatabaseEnabled(true);
  webView.addJavascriptInterface(new FileBridge(),"Android");
  webView.setWebViewClient(new WebViewClient(){@Override public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r){return false;}});
  webView.setWebChromeClient(new WebChromeClient(){
   @Override public boolean onShowFileChooser(WebView v,ValueCallback<Uri[]> cb,FileChooserParams params){
    if(fileCallback!=null)fileCallback.onReceiveValue(null); fileCallback=cb;
    Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT); i.addCategory(Intent.CATEGORY_OPENABLE); i.setType("*/*");
    i.putExtra(Intent.EXTRA_MIME_TYPES,new String[]{"application/json","text/json","application/octet-stream"});
    try{startActivityForResult(i,FILE_CHOOSER);}catch(Exception e){fileCallback=null;cb.onReceiveValue(null);return false;} return true;
   }
  });
  webView.loadUrl("file:///android_asset/index.html");
 }
 private class FileBridge {
  @JavascriptInterface public void saveFile(String name,String mime,String encoded){
   try{
    byte[] bytes=Base64.decode(encoded,Base64.DEFAULT); ContentValues v=new ContentValues();
    v.put(MediaStore.Downloads.DISPLAY_NAME,name);v.put(MediaStore.Downloads.MIME_TYPE,mime);
    v.put(MediaStore.Downloads.RELATIVE_PATH,Environment.DIRECTORY_DOWNLOADS);
    Uri uri=getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI,v);if(uri==null)throw new Exception();
    try(OutputStream out=getContentResolver().openOutputStream(uri)){out.write(bytes);}
    runOnUiThread(()->Toast.makeText(MainActivity.this,"تم حفظ الملف في مجلد التنزيلات",Toast.LENGTH_LONG).show());
   }catch(Exception e){runOnUiThread(()->Toast.makeText(MainActivity.this,"تعذر حفظ الملف",Toast.LENGTH_LONG).show());}
  }
 }
 @Override protected void onActivityResult(int requestCode,int resultCode,Intent data){
  super.onActivityResult(requestCode,resultCode,data);
  if(requestCode==FILE_CHOOSER&&fileCallback!=null){Uri[] result=null;if(resultCode==RESULT_OK&&data!=null&&data.getData()!=null)result=new Uri[]{data.getData()};fileCallback.onReceiveValue(result);fileCallback=null;}
 }
 @Override public void onBackPressed(){if(webView!=null&&webView.canGoBack())webView.goBack();else super.onBackPressed();}
 @Override protected void onDestroy(){if(webView!=null){webView.removeJavascriptInterface("Android");webView.destroy();}super.onDestroy();}
}
