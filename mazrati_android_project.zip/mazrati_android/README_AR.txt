مشروع تطبيق مزرعتي للأرانب – Android WebView
هذا مشروع مصدر جاهز للبناء، وليس ملف APK مبنيًا.
يتطلب Android Studio وAndroid SDK وGradle. الحد الأدنى Android 10 (API 29).
افتح مجلد Mazrati في Android Studio وانتظر مزامنة Gradle.
اختر Build > Build Bundle(s) / APK(s) > Build APK(s).
المسار المعتاد للملف الناتج: app/build/outputs/apk/debug/app-debug.apk
للتوزيع أنشئ توقيع Release واحتفظ بمفتاح التوقيع بأمان.
النسخ الاحتياطية تصدر إلى مجلد Downloads، والاستعادة عبر اختيار ملف JSON.
لا يوجد ربط تلقائي بـGoogle Drive ولا مساعد ذكاء اصطناعي سحابي حتى الآن.

بناء APK من الهاتف عبر GitHub Actions (يحتاج حساب GitHub واتصال إنترنت):
1) أنشئ مستودعًا جديدًا على GitHub.
2) ارفع جميع محتويات مجلد mazrati_android إلى جذر المستودع، وليس ملف ZIP نفسه.
3) افتح تبويب Actions ثم اختر Build Mazrati APK واضغط Run workflow.
4) بعد انتهاء البناء بنجاح، افتح تشغيل workflow ثم نزّل Artifact باسم mazrati-debug-apk.
5) فك ضغط Artifact، ثم ثبّت app-debug.apk على هاتف Android. قد يطلب Android السماح بالتثبيت من هذا المصدر.
هذا APK تجريبي Debug للتثبيت الشخصي، وليس إصدار متجر موقّعًا للنشر.
